import { TranspipePipe } from './transpipe.pipe';

describe('TranspipePipe', () => {
  it('create an instance', () => {
    const pipe = new TranspipePipe();
    expect(pipe).toBeTruthy();
  });
});
