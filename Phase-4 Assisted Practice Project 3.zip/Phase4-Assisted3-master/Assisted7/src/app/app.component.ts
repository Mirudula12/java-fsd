import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 

  value:string="Hi users"

  cval:string="blue";


  show=true;


  op:string="+";
  num1:number=2;
  num2:number=5;


}
