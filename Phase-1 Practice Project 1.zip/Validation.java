import java.util.ArrayList;
import java.util.*;

public class Validation {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("mirudula@gmail.com");
		list.add("gokul1@gmail.com");
		list.add("arun12@gmail.com");
		list.add("rohit7@gmail.com");
		
		System.out.println(list);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter emailid:");
		String searchstr=null;
		searchstr = sc.nextLine();
		
		if(list.contains(searchstr)) {
			System.out.println("\nMailId is Found");
		}
		else {
			System.out.println("\nMailId is Not Found");
		}
	}

}
